import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";

const scryptAsync = promisify(scrypt);

// Helper to hash password
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Helper to compare password
async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedPasswordBuf = Buffer.from(hashed, "hex");
  const suppliedPasswordBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "tasleem_secret_key",
    resave: false,
    saveUninitialized: false,
    store: undefined, // Memory store by default
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    }
  };

  if (app.get("env") === "production") {
    app.set("trust proxy", 1);
  }

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "phone" }, // Use phone as username
      async (phone, password, done) => {
        try {
          const user = await storage.getUserByPhone(phone);
          if (!user) {
            return done(null, false, { message: "Invalid credentials" });
          }
          
          // For seeded data (plain text check fallback for demo, though we should hash everything)
          // To make it robust:
          let isValid = false;
          if (user.password.includes(".")) {
             isValid = await comparePasswords(password, user.password);
          } else {
             isValid = user.password === password; // Fallback for simple seeded data if not hashed
          }

          if (!isValid) {
            return done(null, false, { message: "Invalid credentials" });
          }
          return done(null, user);
        } catch (err) {
          return done(err);
        }
      }
    )
  );

  passport.serializeUser((user, done) => {
    done(null, (user as User).id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Auth Routes
  app.post("/api/auth/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByPhone(req.body.phone);
      if (existingUser) {
        return res.status(400).json({ message: "رقم الهاتف مسجل بالفعل" });
      }

      // Secure phone validation
      if (!/^07[0-9]{9}$/.test(req.body.phone)) {
        return res.status(400).json({ message: "رقم هاتف عراقي غير صالح" });
      }

      const hashedPassword = await hashPassword(req.body.password);
      const merchantId = `TS-${Math.floor(1000 + Math.random() * 9000)}`;

      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
        merchantId,
        role: 'merchant',
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/auth/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/auth/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    res.json(req.user);
  });
}
