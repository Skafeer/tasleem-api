import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";
// الاستيرادات الجديدة اللازمة لإصلاح الحذف
import { db } from "./db";
import { favorites, orderItems, products } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  setupAuth(app);

  // Setup Object Storage
  // نترك هذه كما هي، ولكننا سنضيف المسار اليدوي أدناه لضمان العمل
  registerObjectStorageRoutes(app);

  // --- إصلاح مشكلة رفع الصور ---
  // نضيف هذا المسار يدوياً للتأكد من أن السيرفر يستجيب لطلب الرفع
  app.post("/api/replit-object-storage/upload-url", async (req, res) => {
    // التحقق من الصلاحيات
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.status(403).json({ message: "غير مصرح" });
    }

    try {
      // محاولة استخدام مكتبة Replit إذا كانت متوفرة
      const { objectStorage } = await import("@replit/object-storage");
      const { filename, contentType } = req.body;

      if (!filename || !contentType) {
        return res.status(400).json({ message: "Filename and contentType are required" });
      }

      const { uploadUrl, publicUrl } = await objectStorage.getUploadUrl(filename, {
        contentType,
      });

      res.json({ uploadUrl, publicUrl });
    } catch (error) {
      console.error("Upload Error:", error);
      // في حالة عدم تفعيل Object Storage، نعيد خطأ واضحاً
      res.status(500).json({ message: "يرجى تفعيل Object Storage من قائمة Tools في Replit" });
    }
  });

  app.patch(api.auth.updateProfile.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const user = await storage.updateUser(req.user.id, req.body);
    res.json(user);
  });

  // Products
  app.get(api.products.list.path, async (req, res) => {
    const productsList = await storage.getProducts();
    const { category, search } = req.query;
    let filtered = productsList;
    if (category) {
      filtered = filtered.filter(p => p.category === category);
    }
    if (search) {
      const term = String(search).toLowerCase();
      filtered = filtered.filter(p => p.name.toLowerCase().includes(term));
    }
    res.json(filtered);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  });

  app.post(api.products.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.status(403).json({ message: "Unauthorized" });
    }
    const product = await storage.createProduct(req.body);
    res.status(201).json(product);
  });

  app.put(api.products.update.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.status(403).json({ message: "Unauthorized" });
    }
    const product = await storage.updateProduct(Number(req.params.id), req.body);
    res.json(product);
  });

  // --- إصلاح مشكلة حذف المنتجات ---
  app.delete(api.products.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.status(403).json({ message: "Unauthorized" });
    }

    const productId = Number(req.params.id);

    try {
      // 1. حذف المنتج من المفضلة أولاً (لأنها مرتبطة به)
      await db.delete(favorites).where(eq(favorites.productId, productId));

      // 2. التحقق مما إذا كان المنتج مرتبطاً بطلبات موجودة
      const associatedOrders = await db.select().from(orderItems).where(eq(orderItems.productId, productId)).limit(1);

      if (associatedOrders.length > 0) {
        // إذا كان المنتج في طلبات سابقة، نمنع حذفه لحماية سجل الطلبات
        return res.status(400).json({ 
          message: "لا يمكن حذف هذا المنتج لأنه موجود في طلبات سابقة. يمكنك تعديل الكمية إلى 0 لإخفائه." 
        });
      }

      // 3. إذا لم تكن هناك طلبات، نقوم بحذف المنتج نهائياً
      // نستخدم db مباشرة هنا لضمان العمل حتى لو لم يتم تحديث ملف storage.ts
      await db.delete(products).where(eq(products.id, productId));

      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Delete error:", error);
      res.status(500).json({ message: "فشل الحذف بسبب خطأ في السيرفر" });
    }
  });

  app.post(api.products.toggleFavorite.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const isFavorite = await storage.toggleFavorite(req.user.id, Number(req.params.id));
    res.json({ isFavorite });
  });

  app.get(api.products.isFavorite.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const isFavorite = await storage.isProductFavorited(req.user.id, Number(req.params.id));
    res.json({ isFavorite });
  });

  // Orders
  app.get(api.orders.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });

    // Admins see all, merchants see theirs
    const merchantId = req.user.role === 'admin' ? undefined : req.user.id;
    const orders = await storage.getOrders(merchantId);
    res.json(orders);
  });

  app.get(api.orders.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });

    const order = await storage.getOrder(Number(req.params.id));
    if (!order) return res.status(404).json({ message: "Order not found" });

    // Access control
    if (req.user.role !== 'admin' && order.merchantId !== req.user.id) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    res.json(order);
  });

  app.post(api.orders.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });

    try {
      const { items, ...orderData } = api.orders.create.input.parse(req.body);

      // Calculate totals
      let totalAmount = 0;
      let totalCost = 0;

      // We need to fetch current wholesale prices
      const enrichedItems = await Promise.all(items.map(async (item) => {
        const product = await storage.getProduct(item.productId);
        if (!product) throw new Error(`Product ${item.productId} not found`);

        totalAmount += Number(item.sellingPrice) * item.quantity;
        totalCost += product.wholesalePrice * item.quantity;

        return {
          productId: item.productId,
          quantity: item.quantity,
          price: Number(item.sellingPrice),
          cost: product.wholesalePrice,
        };
      }));

      // Shipping calculation
      const isBasra = orderData.province.toLowerCase().includes('basra') || orderData.province.includes('بصرة');
      const shippingCost = isBasra ? 3000 : 5000;

      // Profit is simply Selling Price - Wholesale Cost
      // Total amount for customer is Selling Price + Shipping
      const totalProfit = totalAmount - totalCost;
      const totalCustomerAmount = totalAmount + shippingCost;

      const order = await storage.createOrder({
        ...orderData,
        merchantId: req.user.id,
        totalAmount: totalCustomerAmount,
        totalProfit,
        shippingCost,
        status: 'pending',
      }, enrichedItems);

      // Add profit to pending balance
      const currentUser = await storage.getUser(req.user.id);
      if (currentUser) {
        await storage.updateUser(req.user.id, {
          pendingBalance: currentUser.pendingBalance + totalProfit
        });
      }

      res.status(201).json(order);
    } catch (e) {
      if (e instanceof Error) {
        res.status(400).json({ message: e.message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.patch(api.orders.updateStatus.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.status(403).json({ message: "Unauthorized" });
    }

    const order = await storage.getOrder(Number(req.params.id));
    if (!order) return res.status(404).json({ message: "Order not found" });

    const newStatus = req.body.status;
    const oldStatus = order.status;

    const updatedOrder = await storage.updateOrder(Number(req.params.id), { status: newStatus });

    // Handle Profit Transfer: Delivered -> Available Balance
    if (newStatus === 'delivered' && oldStatus !== 'delivered') {
      const merchant = await storage.getUser(order.merchantId);
      if (merchant) {
        const pendingBalance = Math.max(0, merchant.pendingBalance - order.totalProfit);
        const availableBalance = merchant.balance + order.totalProfit;

        await storage.updateUser(merchant.id, {
          pendingBalance,
          balance: availableBalance,
        });

        console.log(`Profit transfer successful for Order #${order.id}. Merchant ID: ${merchant.id}. Transferred: ${order.totalProfit}. New Available: ${availableBalance}. New Pending: ${pendingBalance}.`);
      }
    }

    res.json(updatedOrder);
  });

  // Withdrawals
  app.get(api.withdrawals.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const merchantId = req.user.role === 'admin' ? undefined : req.user.id;
    const list = await storage.getWithdrawals(merchantId);
    res.json(list);
  });

  app.post(api.withdrawals.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });

    const { amount, method, accountDetails } = req.body;

    if (amount <= 0) {
      return res.status(400).json({ message: "Invalid amount" });
    }

    if (req.user.balance < amount) {
      return res.status(400).json({ message: "Insufficient balance" });
    }

    try {
      const withdrawal = await storage.createWithdrawal({
        merchantId: req.user.id,
        amount,
        method,
        accountDetails,
        status: 'pending',
      });

      const updatedUser = await storage.updateUser(req.user.id, {
        balance: req.user.balance - amount
      });

      req.login(updatedUser, (err) => {
        if (err) console.error("Session update error:", err);
        res.status(201).json(withdrawal);
      });
    } catch (e) {
      res.status(500).json({ message: "Failed to create withdrawal" });
    }
  });

  app.patch(api.withdrawals.updateStatus.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      return res.status(403).json({ message: "Unauthorized" });
    }

    const { status } = req.body;
    const withdrawal = await storage.getWithdrawal(Number(req.params.id));
    if (!withdrawal) return res.status(404).json({ message: "Withdrawal not found" });

    if (withdrawal.status !== 'pending') {
      return res.status(400).json({ message: "Withdrawal already processed" });
    }

    const updatedWithdrawal = await storage.updateWithdrawal(Number(req.params.id), {
      status
    });

    if (status === 'rejected') {
       const merchant = await storage.getUser(withdrawal.merchantId);
       if (merchant) {
         await storage.updateUser(merchant.id, {
           balance: merchant.balance + withdrawal.amount
         });
       }
    }

    res.json(updatedWithdrawal);
  });

  // Seed Database (Admin user and some products)
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const admin = await storage.getUserByPhone("07700000000");
  if (!admin) {
    await storage.createUser({
      storeName: "Tasleem Admin",
      phone: "07700000000",
      password: "admin", 
      address: "Baghdad",
      role: "admin",
      merchantId: "TS-ADMIN",
    });

    await storage.createUser({
      storeName: "Ali Store",
      phone: "07800000000",
      password: "user123",
      address: "Basra",
      role: "merchant",
      merchantId: "TS-1001",
    });

    await storage.createProduct({
      name: "Wireless Earbuds Pro",
      description: "High quality noise cancelling earbuds with 24h battery life.",
      wholesalePrice: 15000,
      sellingPriceMin: 20000,
      quantity: 50,
      imageUrl: "https://placehold.co/600x400/png",
      category: "Electronics",
    });

    await storage.createProduct({
      name: "Smart Watch Series 5",
      description: "Fitness tracker, heart rate monitor, waterproof.",
      wholesalePrice: 25000,
      sellingPriceMin: 35000,
      quantity: 30,
      imageUrl: "https://placehold.co/600x400/png",
      category: "Electronics",
    });

    await storage.createProduct({
      name: "Men's Leather Wallet",
      description: "Genuine leather wallet, brown.",
      wholesalePrice: 8000,
      sellingPriceMin: 12000,
      quantity: 100,
      imageUrl: "https://placehold.co/600x400/png",
      category: "Fashion",
    });
  }
}