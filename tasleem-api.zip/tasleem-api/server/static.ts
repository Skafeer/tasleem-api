import { Express } from "express";
export function serveStatic(app: Express) {
  // API only - no static files
}
