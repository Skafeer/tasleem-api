import { db } from "./db";
import {
  users,
  products,
  orders,
  orderItems,
  withdrawals,
  favorites,
  type User,
  type InsertUser,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type Withdrawal,
  type InsertWithdrawal,
  type OrderItem,
  type InsertOrderItem,
  type Favorite,
} from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser & { merchantId: string }): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product>;
  
  // Orders
  getOrders(merchantId?: number): Promise<(Order & { items: (OrderItem & { product: Product | null })[] })[]>;
  getOrder(id: number): Promise<(Order & { items: (OrderItem & { product: Product | null })[] }) | undefined>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order>;

  // Withdrawals
  getWithdrawals(merchantId?: number): Promise<Withdrawal[]>;
  getWithdrawal(id: number): Promise<Withdrawal | undefined>;
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  updateWithdrawal(id: number, updates: Partial<Withdrawal>): Promise<Withdrawal>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    return user;
  }

  async createUser(user: InsertUser & { merchantId: string }): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async getProducts(): Promise<Product[]> {
    return await db.select().from(products).orderBy(desc(products.createdAt));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values({
      ...product,
      imageUrl: product.imageUrls && product.imageUrls.length > 0 ? product.imageUrls[0] : (product.imageUrl || ""),
      imageUrls: product.imageUrls || []
    }).returning();
    return newProduct;
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product> {
    const finalUpdates = { ...updates };
    if (updates.imageUrls && updates.imageUrls.length > 0) {
      finalUpdates.imageUrl = updates.imageUrls[0];
    }
    const [updatedProduct] = await db
      .update(products)
      .set(finalUpdates)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct;
  }

  async getOrders(merchantId?: number): Promise<(Order & { items: (OrderItem & { product: Product | null })[] })[]> {
    let query = db.select().from(orders).orderBy(desc(orders.createdAt));
    
    if (merchantId) {
      // @ts-ignore - complex query typing
      query = query.where(eq(orders.merchantId, merchantId));
    }

    const results = await query;
    
    // Fetch items for each order - keeping it simple with N+1 for now as standard Drizzle relation queries can be tricky without `query` builder which requires schema setup
    // Better way:
    return await Promise.all(results.map(async (order) => {
       const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
       const itemsWithProducts = await Promise.all(items.map(async (item) => {
         const [product] = await db.select().from(products).where(eq(products.id, item.productId));
         return { ...item, product: product || null };
       }));
       return { ...order, items: itemsWithProducts };
    }));
  }

  async getOrder(id: number): Promise<(Order & { items: (OrderItem & { product: Product | null })[] }) | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;

    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
    const itemsWithProducts = await Promise.all(items.map(async (item) => {
      const [product] = await db.select().from(products).where(eq(products.id, item.productId));
      return { ...item, product: product || null };
    }));

    return { ...order, items: itemsWithProducts };
  }

  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    return await db.transaction(async (tx) => {
      const [newOrder] = await tx.insert(orders).values(order).returning();
      
      for (const item of items) {
        await tx.insert(orderItems).values({
          ...item,
          orderId: newOrder.id,
        });
        
        const [product] = await tx.select().from(products).where(eq(products.id, item.productId));
        if (product) {
          await tx.update(products)
            .set({ quantity: product.quantity - item.quantity })
            .where(eq(products.id, item.productId));
        }
      }
      
      return newOrder;
    });
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  async getWithdrawals(merchantId?: number): Promise<Withdrawal[]> {
    if (merchantId) {
      return await db.select().from(withdrawals).where(eq(withdrawals.merchantId, merchantId)).orderBy(desc(withdrawals.createdAt));
    }
    return await db.select().from(withdrawals).orderBy(desc(withdrawals.createdAt));
  }

  async getWithdrawal(id: number): Promise<Withdrawal | undefined> {
    const [w] = await db.select().from(withdrawals).where(eq(withdrawals.id, id));
    return w;
  }

  async createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const [newWithdrawal] = await db.insert(withdrawals).values(withdrawal).returning();
    return newWithdrawal;
  }

  async updateWithdrawal(id: number, updates: Partial<Withdrawal>): Promise<Withdrawal> {
    const [updated] = await db
      .update(withdrawals)
      .set(updates)
      .where(eq(withdrawals.id, id))
      .returning();
    return updated;
  }

  // Favorites
  async getFavorites(userId: number): Promise<Favorite[]> {
    return await db.select().from(favorites).where(eq(favorites.userId, userId));
  }

  async isProductFavorited(userId: number, productId: number): Promise<boolean> {
    const [fav] = await db.select().from(favorites).where(and(eq(favorites.userId, userId), eq(favorites.productId, productId)));
    return !!fav;
  }

  async toggleFavorite(userId: number, productId: number): Promise<boolean> {
    const [existing] = await db.select().from(favorites).where(and(eq(favorites.userId, userId), eq(favorites.productId, productId)));
    if (existing) {
      await db.delete(favorites).where(eq(favorites.id, existing.id));
      return false;
    } else {
      await db.insert(favorites).values({ userId, productId });
      return true;
    }
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }
}

export const storage = new DatabaseStorage();
