import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  merchantId: text("merchant_id").unique(), // TS-XXXX
  storeName: text("store_name").notNull(),
  phone: text("phone").notNull().unique(), // 11 digits, starts with 07
  password: text("password").notNull(),
  address: text("address").notNull(),
  backupPhone: text("backup_phone"),
  role: text("role").default("merchant").notNull(), // 'merchant' | 'admin'
  balance: integer("balance").default(0).notNull(), // Available for withdrawal
  pendingBalance: integer("pending_balance").default(0).notNull(), // Pending delivery
  isActive: boolean("is_active").default(true).notNull(),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  wholesalePrice: integer("wholesale_price").notNull(), // Trader wholesale price
  employeeWholesalePrice: integer("employee_wholesale_price").default(0).notNull(), // New: hidden from traders
  sellingPriceMin: integer("selling_price_min").notNull(), 
  quantity: integer("quantity").notNull(), 
  imageUrls: text("image_urls").array().default([]).notNull(), // Updated: support up to 10 images
  imageUrl: text("image_url").notNull(), // Keep for backwards compatibility
  category: text("category").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").references(() => users.id).notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  province: text("province").notNull(), 
  address: text("address").notNull(),
  status: text("status").default("pending").notNull(), 
  totalAmount: integer("total_amount").notNull(), 
  totalProfit: integer("total_profit").notNull(), 
  shippingCost: integer("shipping_cost").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  quantity: integer("quantity").notNull(),
  price: integer("price").notNull(), // This is the Selling Price entered by merchant
  cost: integer("cost").notNull(), 
});

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").references(() => users.id).notNull(),
  amount: integer("amount").notNull(),
  method: text("method").notNull(), 
  accountDetails: text("account_details").notNull(),
  status: text("status").default("pending").notNull(), 
  createdAt: timestamp("created_at").defaultNow(),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").unique().notNull(),
  value: jsonb("value").notNull(),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  orders: many(orders),
  withdrawals: many(withdrawals),
  favorites: many(favorites),
}));

export const productsRelations = relations(products, ({ many }) => ({
  favoritedBy: many(favorites),
}));

export const favoritesRelations = relations(favorites, ({ one }) => ({
  user: one(users, {
    fields: [favorites.userId],
    references: [users.id],
  }),
  product: one(products, {
    fields: [favorites.productId],
    references: [products.id],
  }),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  merchant: one(users, {
    fields: [orders.merchantId],
    references: [users.id],
  }),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id],
  }),
}));

export const withdrawalsRelations = relations(withdrawals, ({ one }) => ({
  merchant: one(users, {
    fields: [withdrawals.merchantId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  merchantId: true,
  balance: true,
  pendingBalance: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  totalProfit: true, 
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
});

export const insertWithdrawalSchema = createInsertSchema(withdrawals).omit({
  id: true,
  createdAt: true,
  status: true,
});

// === EXPLICIT API CONTRACT TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Favorite = typeof favorites.$inferSelect;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

export type Withdrawal = typeof withdrawals.$inferSelect;
export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;

// Auth Types
export type LoginRequest = {
  phone: string;
  password: string;
};

// Request Types
export type CreateOrderRequest = {
  items: { productId: number; quantity: number; sellingPrice: number }[];
  customerName: string;
  customerPhone: string;
  province: string;
  address: string;
  notes?: string;
};

export type UpdateOrderStatusRequest = {
  status: string;
};

// Response Types
export type AuthResponse = User;
export type ProductResponse = Product;
export type OrderResponse = Order & { items?: (OrderItem & { product?: Product })[] };
export type WithdrawalResponse = Withdrawal;
